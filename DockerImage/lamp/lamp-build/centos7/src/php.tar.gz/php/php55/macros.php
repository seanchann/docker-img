#
# Interface versions exposed by PHP:
# 
%php_core_api @PHP_APIVER@
%php_zend_api @PHP_ZENDVER@
%php_pdo_api @PHP_PDOVER@

%php_extdir %{_libdir}/php/modules
